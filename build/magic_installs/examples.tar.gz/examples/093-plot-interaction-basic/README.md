This app demonstrates basic plot interactions, with both base graphics and ggplot2.

The four types of interactions are: clicking, double-clicking, hovering, and brushing.
