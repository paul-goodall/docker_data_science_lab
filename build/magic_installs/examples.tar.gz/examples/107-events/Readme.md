This app demonstrates the JavaScript events in Shiny.
