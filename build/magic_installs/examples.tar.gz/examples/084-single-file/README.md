This example shows how to make an app with a single file, app.R, instead of using the two files server.R and ui.R.
